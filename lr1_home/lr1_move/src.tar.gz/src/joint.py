#!/usr/bin/env python

class Joint:

    def __init__(self , name):
        self.name = name

        self.position = 0.0
        self.velocity = 0.0
